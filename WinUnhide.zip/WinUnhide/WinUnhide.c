/* 
          http://www.unhide-forensics.info
*/

/*
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define _WIN32_WINNT 0x0502

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <windows.h>
#include <tchar.h>
#include <tlhelp32.h>

// Windows
#define COMMAND "wmic process get ProcessId"

DWORD maxpid = 1000000;


void checkps( wint_t tmppid) {

	int ok = 0;
	char pids[100];
	char compare[100];

	FILE *fich_tmp ;

	fich_tmp=popen (COMMAND, "r") ;


	while (!feof(fich_tmp) && ok == 0) {

		fgets(pids, 30, fich_tmp);
		
		int pid = atoi(pids) ;

		sprintf(compare,"%i\r\n",tmppid);
		
		if (pid == tmppid) {ok = 1;}

        }

	pclose(fich_tmp);

	if ( ok == 0 ) {

		printf ("Found HIDDEN PID: %i\n", tmppid) ;

	}

}

void checkopen() {

	int syspids ;
	DWORD home;

	HANDLE hProcess;
	
	HMODULE hMods[1024];
	DWORD cbNeeded;
	DWORD dwPriorityClass;

	printf ("[*]Searching for Hidden processes through openprocess() scanning\n\n") ;
	
	for ( syspids = 1; syspids <= maxpid; syspids = syspids +1 ) {
		
		if((syspids%4)==0) {
			
			hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, syspids );
		
			int errorn ;
		
			errorn = GetLastError() ;
		
			//printf("Last error result : %i\n", errorn);
			
			if ( !hProcess == NULL ) {
			
				dwPriorityClass = 0;
			
				DWORD lpExitCode ;
			
				GetExitCodeProcess(hProcess, &lpExitCode) ;
			
				if( lpExitCode != 0 ) {
				
					checkps(syspids);
					CloseHandle( hProcess );
				
				}
				
			} 
		}
	}
}

void checktoolhelp() {
	
	printf ("[*]Searching for Hidden processes through Toolhelp scanning\n\n") ;
	
	HANDLE hSnapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
	
	PROCESSENTRY32 pe;

	pe.dwSize=sizeof(PROCESSENTRY32);

	BOOL retval=Process32First(hSnapshot,&pe);
	
	while(retval) {
		
		//printf("Process ID : %i\n",pe.th32ProcessID);
		
		checkps(pe.th32ProcessID) ;
		
		pe.dwSize=sizeof(PROCESSENTRY32);
		retval=Process32Next(hSnapshot,&pe);
	}

	CloseHandle(hSnapshot);

}

int main (int argc, char *argv[]) {
	
	printf ("Unhide 20110113\n") ;
	printf ("http://www.unhide-forensics.info\n\n\n") ;


	if(argc != 2) {

		printf("usage: %s sys \n\n", argv[0]);
		exit (1);

	}

	else if (strcmp(argv[1], "sys") == 0) {
		checkopen();
		checktoolhelp();

	}
	
	else {
		printf("uso: %s sys\n\n", argv[0]);
		exit (1);
	}

}


