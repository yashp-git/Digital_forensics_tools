/* 
          http://www.unhide-forensics.info
*/

/*
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


// To compile: gcc WinUnhide-tcp.c -o WinUnhide-tcp -lIphlpapi -l Ws2_32

#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <winsock2.h>
#include <Ws2tcpip.h>



#define MALLOC(x) HeapAlloc(GetProcessHeap(), 0, (x))
#define FREE(x) HeapFree(GetProcessHeap(), 0, (x))

int main()
{
	
	char tcpports[65535] ;
	
	PMIB_TCPTABLE pTcpTable;
	DWORD dwSize = 0;
	DWORD dwRetVal = 0;

	int i;
	
	printf ("Unhide 20110113\n") ;
        printf ("http://www.unhide-forensics.info\n\n\n") ;

	pTcpTable = (MIB_TCPTABLE *) MALLOC(sizeof (MIB_TCPTABLE));
	if (pTcpTable == NULL) {
		printf("Error allocating memory\n");
		return 1;
	}

	dwSize = sizeof (MIB_TCPTABLE);
	
	printf ("Open TCP ports through GetTcpTable()\n\n") ; 
	
	if ((dwRetVal = GetTcpTable(pTcpTable, &dwSize, TRUE)) == ERROR_INSUFFICIENT_BUFFER) {
		FREE(pTcpTable);
		pTcpTable = (MIB_TCPTABLE *) MALLOC(dwSize);
		if (pTcpTable == NULL) {
			printf("Error allocating memory\n");
			return 1;
		}
	}
	
	if ((dwRetVal = GetTcpTable(pTcpTable, &dwSize, TRUE)) == NO_ERROR) {
  
		for (i = 0; i < (int) pTcpTable->dwNumEntries; i++) {
		
			if (pTcpTable->table[i].dwState == MIB_TCP_STATE_LISTEN) {
				
				printf("%d \n", ntohs((u_short)pTcpTable->table[i].dwLocalPort));
				
				tcpports[ntohs((u_short)pTcpTable->table[i].dwLocalPort)] = 1 ;
				
			}
           
		}
	} 
	else {
		printf("\tGetTcpTable failed with %d\n", dwRetVal);
		FREE(pTcpTable);
		return 1;
	}

	if (pTcpTable != NULL) {
		FREE(pTcpTable);
		pTcpTable = NULL;
	}

	printf ("\n[*]Searching for Hidden TCP ports through bind() scanning\n\n") ;
	
	for (i =1; i <= 65535; i++) {

		WSADATA wsaData;

		int iResult = 0; 

		SOCKET ListenSocket = INVALID_SOCKET;

		struct sockaddr_in service;
		
		iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
		if (iResult != NO_ERROR) {
			wprintf(L"Error at WSAStartup()\n");
			return 1;
		}
    
		ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (ListenSocket == INVALID_SOCKET) {
			wprintf(L"socket function failed with error: %u\n", WSAGetLastError());
			WSACleanup();
			return 1;
		}
    
		service.sin_family = AF_INET;
		service.sin_addr.s_addr = inet_addr("0.0.0.0");
		service.sin_port = htons(i);
		
		iResult = bind(ListenSocket, (SOCKADDR *) &service, sizeof (service));
		if (iResult == SOCKET_ERROR) {

			closesocket(ListenSocket);
			
			int portfind = 0 ;
			
			PMIB_TCPTABLE pTcpTable;
			DWORD dwSize = 0;
			DWORD dwRetVal = 0;
			
			if ((dwRetVal = GetTcpTable(pTcpTable, &dwSize, TRUE)) == ERROR_INSUFFICIENT_BUFFER) {
				FREE(pTcpTable);
				pTcpTable = (MIB_TCPTABLE *) MALLOC(dwSize);
				if (pTcpTable == NULL) {
					printf("Error allocating memory\n");
					return 1;
				}
			}
			
			if ((dwRetVal = GetTcpTable(pTcpTable, &dwSize, TRUE)) == NO_ERROR) {
				
				int z ;
				
				for (z = 0; z < (int) pTcpTable->dwNumEntries; z++) {
		
					if (ntohs((u_short)pTcpTable->table[z].dwLocalPort) == i ) {
				
						portfind = 1 ; 
				
					}
           
				}
			}

			if (portfind == 0) {
				
				printf ("Found Hidden port %i\n", i) ;

			}
			
		}
		
		else { closesocket(ListenSocket); }
		
	}
	
	
	// UDP 
	
	PMIB_UDPTABLE pUdpTable;
	dwSize = 0;
	dwRetVal = 0;
	
	unsigned short *port_ptr;

	pUdpTable = (MIB_UDPTABLE *) MALLOC(sizeof (MIB_UDPTABLE));
	if (pUdpTable == NULL) {
		printf("Error allocating memory\n");
		return 1;
	}

	dwSize = sizeof (MIB_UDPTABLE);
	
	printf ("Open UDP ports through GetUdpTable()\n\n") ; 
	
	if ((dwRetVal = GetUdpTable(pUdpTable, &dwSize, TRUE)) == ERROR_INSUFFICIENT_BUFFER) {
		FREE(pUdpTable);
		pUdpTable = (MIB_UDPTABLE *) MALLOC(dwSize);
		if (pUdpTable == NULL) {
			printf("Error allocating memory\n");
			return 1;
		}
	}
	
	if ((dwRetVal = GetUdpTable(pUdpTable, &dwSize, TRUE)) == NO_ERROR) {
  
		for (i=0; i<pUdpTable->dwNumEntries; i++) {
				
			port_ptr = (unsigned short *)&pUdpTable->table[i].dwLocalPort;
			printf("%ld\n",htons(*port_ptr));
		}
	} 
	else {
		printf("\tGetUdpTable failed with %d\n", dwRetVal);
		FREE(pUdpTable);
		return 1;
	}

	if (pUdpTable != NULL) {
		FREE(pUdpTable);
		pUdpTable = NULL;
	} 
	
	printf ("\n[*]Searching for Hidden UDP ports through bind() scanning\n\n") ;
	
	for (i =1; i <= 65535; i++) {

		WSADATA wsaData;

		int iResult = 0; 

		SOCKET ListenSocket = INVALID_SOCKET;
		
		struct sockaddr_in service;

		iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
		if (iResult != NO_ERROR) {
			wprintf(L"Error at WSAStartup()\n");
			return 1;
		}
    
		ListenSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
		if (ListenSocket == INVALID_SOCKET) {
			wprintf(L"socket function failed with error: %u\n", WSAGetLastError());
			WSACleanup();
			return 1;
		}
    
		service.sin_family = AF_INET;
		service.sin_addr.s_addr = inet_addr("0.0.0.0");
		service.sin_port = htons(i);
		
		iResult = bind(ListenSocket, (SOCKADDR *) &service, sizeof (service));
		
		if (iResult == SOCKET_ERROR) {

			closesocket(ListenSocket);
			
			int portfind = 0 ;
			
			PMIB_UDPTABLE pUdpTable;
			dwSize = 0;
			dwRetVal = 0;

			unsigned short *port_ptr;

			if ((dwRetVal = GetUdpTable(pUdpTable, &dwSize, TRUE)) == ERROR_INSUFFICIENT_BUFFER) {
				FREE(pUdpTable);
				pUdpTable = (MIB_UDPTABLE *) MALLOC(dwSize);
				if (pUdpTable == NULL) {
					printf("Error allocating memory\n");
					return 1;
				}
			}
	
			if ((dwRetVal = GetUdpTable(pUdpTable, &dwSize, TRUE)) == NO_ERROR) {
				
				int z ;
				
				for (z=0; z<pUdpTable->dwNumEntries; z++) {
				
					port_ptr = (unsigned short *)&pUdpTable->table[z].dwLocalPort;
						
					if (htons(*port_ptr) == i) {
							
						portfind = 1 ;
					}
				}
			}
			
			if (portfind == 0) {
				
				printf ("Found Hidden port %i\n", i) ;

			}
			
		}
		
		else { closesocket(ListenSocket); }
		
	}
	
	
	
}

